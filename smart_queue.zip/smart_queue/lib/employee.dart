import 'package:flutter/material.dart';
import 'state.dart';
import 'widgets.dart';

class EmployeeShell extends StatefulWidget {
  const EmployeeShell({super.key});

  @override
  State<EmployeeShell> createState() => _EmployeeShellState();
}

class _EmployeeShellState extends State<EmployeeShell> {
  String? _sid;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final u = app.me;
        if (u == null || u.placeId == null) return const SizedBox.shrink();
        final place = app.placeById(u.placeId!);
        final services = app.servicesOf(place.id);
        return Scaffold(
          appBar: AppBar(
            title: Text(place.name),
            actions: const [LangButton(), LogoutButton()],
          ),
          body: services.isEmpty
              ? EmptyState(
                  icon: Icons.inbox,
                  title: tr('لا توجد خدمات لهذا المكان', 'No services for this place'),
                )
              : _body(context, u, place, services),
        );
      },
    );
  }

  Widget _gap(Widget w) => Padding(padding: const EdgeInsets.only(bottom: 12), child: w);

  Widget _body(BuildContext context, AppUser u, Place place, List<Service> services) {
    final s = services.firstWhere((x) => x.id == _sid, orElse: () => services.first);
    final cur = app.currentOf(s.id);
    final queue = app.queueOf(s.id);
    final done = app.todayTickets
        .where((t) => t.serviceId == s.id && t.status == TicketStatus.completed)
        .length;
    final canCall = !s.paused && cur == null && queue.isNotEmpty;
    final hello = tr('مرحبًا', 'Hello');

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _gap(Text('$hello ${u.name}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
        if (services.length > 1)
          _gap(Wrap(
            spacing: 8,
            runSpacing: 4,
            children: [
              for (final x in services)
                ChoiceChip(
                  label: Text(x.name),
                  selected: x.id == s.id,
                  onSelected: (_) => setState(() => _sid = x.id),
                ),
            ],
          )),
        _gap(_controlCard(context, s, place, queue.length, done)),
        _gap(_currentCard(context, s, cur)),
        _gap(FilledButton.icon(
          onPressed: canCall ? () => app.callNext(s) : null,
          style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54)),
          icon: const Icon(Icons.campaign),
          label: Text(tr('نادِ التالي', 'Call next'), style: const TextStyle(fontSize: 17)),
        )),
        Text(
          tr('الطابور (${queue.length})', 'Queue (${queue.length})'),
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        if (queue.isEmpty)
          Padding(
            padding: const EdgeInsets.all(24),
            child: Center(
              child: Text(
                tr('لا يوجد طلاب في الانتظار', 'No students waiting'),
                style: TextStyle(color: Colors.grey.shade600),
              ),
            ),
          ),
        for (int i = 0; i < queue.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: _queueTile(context, i, queue[i]),
          ),
      ],
    );
  }

  Widget _openChip(Service s) {
    String text = tr('مفتوح', 'Open');
    Color c = Colors.green.shade700;
    if (!s.open) {
      text = tr('مغلق', 'Closed');
      c = Colors.grey.shade700;
    } else if (s.paused) {
      text = tr('متوقف مؤقتًا', 'Paused');
      c = Colors.orange.shade800;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: c.withAlpha(30), borderRadius: BorderRadius.circular(20)),
      child: Text(text, style: TextStyle(color: c, fontWeight: FontWeight.bold, fontSize: 12)),
    );
  }

  Widget _controlCard(BuildContext context, Service s, Place place, int waiting, int done) {
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(s.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
              _openChip(s),
            ],
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 16,
            runSpacing: 6,
            children: [
              InfoPill(icon: Icons.people, text: tr('منتظرون: $waiting', 'Waiting: $waiting')),
              InfoPill(icon: Icons.done_all, text: tr('تمت اليوم: $done', 'Done today: $done')),
              InfoPill(icon: Icons.meeting_room, text: tr('شباك ${s.desk}', 'Window ${s.desk}')),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => app.togglePause(s),
                  icon: Icon(s.paused ? Icons.play_arrow : Icons.pause),
                  label: Text(s.paused ? tr('استئناف', 'Resume') : tr('إيقاف مؤقت', 'Pause')),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _showQr(context, place),
                  icon: const Icon(Icons.qr_code_2),
                  label: Text(tr('QR المكتب', 'Office QR')),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _showQr(BuildContext context, Place place) {
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                tr('رمز QR لمكتب ${place.nameAr}', 'QR code for ${place.nameEn}'),
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              OfficeQr(data: 'smartqueue://place/${place.id}', size: 220),
              const SizedBox(height: 12),
              Text(
                tr('يمسحه الطالب لتأكيد وصوله إلى المكتب.', 'Students scan it to confirm their arrival.'),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _currentCard(BuildContext context, Service s, Ticket? cur) {
    if (cur == null) {
      return AppCard(
        child: SizedBox(
          width: double.infinity,
          child: Column(
            children: [
              Icon(Icons.hourglass_empty, color: Colors.grey.shade500, size: 36),
              const SizedBox(height: 6),
              Text(
                tr('لا يوجد طالب حاليًا. اضغط "نادِ التالي".', 'No student right now. Tap "Call next".'),
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey.shade700),
              ),
            ],
          ),
        ),
      );
    }
    final student = app.userById(cur.studentId);
    final called = cur.status == TicketStatus.called;
    return AppCard(
      color: const Color(0xFFE8F5E9),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(cur.code, style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900)),
              const SizedBox(width: 12),
              StatusChip(cur.status),
              if (cur.priority) ...[
                const SizedBox(width: 8),
                const Text('★', style: TextStyle(color: Colors.amber, fontSize: 20)),
              ],
            ],
          ),
          const SizedBox(height: 4),
          Text(student?.name ?? '', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Row(
            children: [
              Icon(
                cur.arrived ? Icons.check_circle : Icons.circle_outlined,
                size: 18,
                color: cur.arrived ? Colors.green.shade700 : Colors.grey,
              ),
              const SizedBox(width: 6),
              Text(cur.arrived ? tr('وصل إلى المكتب', 'Arrived at the office') : tr('لم يؤكد وصوله بعد', 'Has not confirmed arrival')),
            ],
          ),
          if (called && !cur.arrived && cur.calledAt != null) ...[
            const SizedBox(height: 6),
            Row(
              children: [
                Text(tr('المهلة المتبقية: ', 'Time left: ')),
                CountdownText(
                  from: cur.calledAt!,
                  seconds: kGraceSeconds,
                  style: TextStyle(fontWeight: FontWeight.bold, color: Colors.red.shade700),
                ),
              ],
            ),
          ],
          const SizedBox(height: 12),
          if (called)
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: () => app.startServing(cur),
                    icon: const Icon(Icons.play_arrow),
                    label: Text(tr('بدء الخدمة', 'Start service')),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () async {
                      final ok = await confirmDialog(
                        context,
                        tr('تخطي الطالب', 'Skip student'),
                        tr('تخطي التذكرة ${cur.code} لعدم الحضور؟', 'Skip ticket ${cur.code} as no-show?'),
                      );
                      if (ok) app.skip(cur);
                    },
                    icon: const Icon(Icons.skip_next),
                    label: Text(tr('تخطي', 'Skip')),
                  ),
                ),
              ],
            )
          else
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () => app.complete(cur),
                icon: const Icon(Icons.done_all),
                label: Text(tr('إنهاء الخدمة', 'Complete service')),
              ),
            ),
        ],
      ),
    );
  }

  Widget _queueTile(BuildContext context, int index, Ticket t) {
    final student = app.userById(t.studentId);
    final waited = DateTime.now().difference(t.createdAt).inMinutes;
    return AppCard(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(
        children: [
          CircleAvatar(
            radius: 16,
            backgroundColor: kPrimary.withAlpha(25),
            child: Text('${index + 1}', style: const TextStyle(color: kPrimary, fontWeight: FontWeight.bold)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(t.code, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    if (t.priority) ...[
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.amber,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(tr('أولوية', 'Priority'), style: const TextStyle(fontSize: 11)),
                      ),
                    ],
                  ],
                ),
                Text(
                  '${student?.name ?? ''} · ${tr('منذ $waited د', '$waited min ago')}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
                ),
              ],
            ),
          ),
          Icon(
            t.arrived ? Icons.check_circle : Icons.circle_outlined,
            color: t.arrived ? Colors.green.shade700 : Colors.grey,
            size: 20,
          ),
          IconButton(
            tooltip: tr('إلغاء التذكرة', 'Cancel ticket'),
            icon: Icon(Icons.close, color: Colors.red.shade700),
            onPressed: () async {
              final ok = await confirmDialog(
                context,
                tr('إلغاء التذكرة', 'Cancel ticket'),
                tr('إلغاء التذكرة ${t.code}؟', 'Cancel ticket ${t.code}?'),
                confirmText: tr('نعم، إلغاء', 'Yes, cancel'),
              );
              if (ok) app.cancelByStaff(t);
            },
          ),
        ],
      ),
    );
  }
}
