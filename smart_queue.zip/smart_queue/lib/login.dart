import 'package:flutter/material.dart';
import 'state.dart';
import 'widgets.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        return Scaffold(
          backgroundColor: kPrimary,
          body: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const LogoMark(size: 96),
                const SizedBox(height: 16),
                Text(
                  tr('الطابور الذكي', 'Smart Queue'),
                  style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 6),
                Text(
                  tr('كلية الذكاء الاصطناعي – جامعة المنوفية', 'Faculty of AI – Menoufia University'),
                  style: const TextStyle(color: Colors.white70),
                ),
                const SizedBox(height: 32),
                const CircularProgressIndicator(color: Colors.white),
              ],
            ),
          ),
        );
      },
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _nid = TextEditingController();
  final TextEditingController _aid = TextEditingController();
  String? _error;

  @override
  void dispose() {
    _nid.dispose();
    _aid.dispose();
    super.dispose();
  }

  void _submit() {
    final err = app.login(_nid.text, _aid.text);
    if (err != null) {
      setState(() => _error = err);
    }
  }

  String _label(AppUser u) {
    if (u.role == Role.student) {
      final first = u.name.split(' ').first;
      return '${tr('طالب', 'Student')}: $first${u.priority ? ' ★' : ''}';
    }
    if (u.role == Role.employee) {
      final pl = app.placeById(u.placeId!).name;
      return '${tr('موظف', 'Staff')}: $pl';
    }
    return tr('الأدمن', 'Admin');
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        return Scaffold(
          backgroundColor: kPrimary,
          body: SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const Align(
                    alignment: AlignmentDirectional.centerEnd,
                    child: LangButton(),
                  ),
                  const SizedBox(height: 4),
                  const LogoMark(size: 84),
                  const SizedBox(height: 12),
                  Text(
                    tr('الطابور الذكي', 'Smart Queue'),
                    style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    tr('كلية الذكاء الاصطناعي – جامعة المنوفية', 'Faculty of AI – Menoufia University'),
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white70),
                  ),
                  const SizedBox(height: 24),
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Text(
                          tr('تسجيل الدخول', 'Log in'),
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 16),
                        TextField(
                          controller: _nid,
                          keyboardType: TextInputType.number,
                          maxLength: 14,
                          decoration: InputDecoration(
                            labelText: tr('الرقم القومي', 'National ID'),
                            prefixIcon: const Icon(Icons.badge_outlined),
                            counterText: '',
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: _aid,
                          decoration: InputDecoration(
                            labelText: tr('الرقم الأكاديمي / كود الموظف', 'Academic ID / Staff code'),
                            prefixIcon: const Icon(Icons.tag),
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                        if (_error != null)
                          Padding(
                            padding: const EdgeInsets.only(top: 10),
                            child: Text(_error!, style: TextStyle(color: Colors.red.shade700)),
                          ),
                        const SizedBox(height: 16),
                        FilledButton(
                          onPressed: _submit,
                          style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)),
                          child: Text(tr('دخول', 'Log in')),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    tr('حسابات تجريبية – اضغط لتعبئة البيانات', 'Demo accounts – tap to fill the form'),
                    style: const TextStyle(color: Colors.white70),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    alignment: WrapAlignment.center,
                    children: [
                      for (final u in app.demoAccounts)
                        ActionChip(
                          label: Text(_label(u)),
                          onPressed: () {
                            _nid.text = u.nationalId;
                            _aid.text = u.academicId;
                            setState(() => _error = null);
                          },
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
