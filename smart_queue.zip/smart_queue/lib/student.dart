import 'package:flutter/material.dart';
import 'state.dart';
import 'widgets.dart';

// ===============================================================
// الهيكل الرئيسي للطالب (شريط سفلي + 4 تبويبات)
// ===============================================================
class StudentShell extends StatefulWidget {
  const StudentShell({super.key});

  @override
  State<StudentShell> createState() => _StudentShellState();
}

class _StudentShellState extends State<StudentShell> {
  int _tab = 0;
  int _seen = 0;

  @override
  void initState() {
    super.initState();
    _seen = app.noticesOf(app.me!.id).length;
    app.addListener(_onApp);
  }

  @override
  void dispose() {
    app.removeListener(_onApp);
    super.dispose();
  }

  // لما يوصل إشعار جديد نعرضه كشريط صغير (محاكاة للإشعارات)
  void _onApp() {
    final u = app.me;
    if (u == null || !mounted) return;
    final list = app.noticesOf(u.id);
    if (list.length > _seen) {
      final n = list.first;
      _seen = list.length;
      final m = ScaffoldMessenger.of(context);
      m.hideCurrentSnackBar();
      m.showSnackBar(SnackBar(
        content: Text('${n.title}: ${n.body}'),
        duration: const Duration(seconds: 4),
      ));
    } else {
      _seen = list.length;
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final u = app.me;
        if (u == null) return const SizedBox.shrink();
        final unread = app.unreadOf(u.id);
        final pages = <Widget>[
          StudentHome(onGoTicket: () => setState(() => _tab = 1)),
          MyTicketScreen(onGoHome: () => setState(() => _tab = 0)),
          const HistoryScreen(),
          const ProfileScreen(),
        ];
        return Scaffold(
          appBar: AppBar(
            title: Text(tr('الطابور الذكي', 'Smart Queue')),
            actions: [
              const LangButton(),
              IconButton(
                tooltip: tr('الإشعارات', 'Notifications'),
                icon: Badge(
                  isLabelVisible: unread > 0,
                  label: Text('$unread'),
                  child: const Icon(Icons.notifications),
                ),
                onPressed: () {
                  app.markRead(u.id);
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const NoticesScreen()),
                  );
                },
              ),
            ],
          ),
          body: pages[_tab],
          bottomNavigationBar: NavigationBar(
            selectedIndex: _tab,
            onDestinationSelected: (i) => setState(() => _tab = i),
            destinations: [
              NavigationDestination(
                icon: const Icon(Icons.home_outlined),
                selectedIcon: const Icon(Icons.home),
                label: tr('الرئيسية', 'Home'),
              ),
              NavigationDestination(
                icon: const Icon(Icons.confirmation_number_outlined),
                selectedIcon: const Icon(Icons.confirmation_number),
                label: tr('تذكرتي', 'My ticket'),
              ),
              NavigationDestination(
                icon: const Icon(Icons.history),
                selectedIcon: const Icon(Icons.history),
                label: tr('السجل', 'History'),
              ),
              NavigationDestination(
                icon: const Icon(Icons.person_outline),
                selectedIcon: const Icon(Icons.person),
                label: tr('حسابي', 'Profile'),
              ),
            ],
          ),
        );
      },
    );
  }
}

// ===============================================================
// الرئيسية: الترحيب + التذكرة الحالية + أماكن الخدمة
// ===============================================================
class StudentHome extends StatelessWidget {
  final VoidCallback onGoTicket;
  const StudentHome({super.key, required this.onGoTicket});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final u = app.me!;
        final active = app.activeTicketOf(u.id);
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            AppCard(
              color: kPrimary,
              child: SizedBox(
                width: double.infinity,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(tr('أهلًا،', 'Welcome,'), style: const TextStyle(color: Colors.white70)),
                    Text(
                      u.name,
                      style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      tr('كلية الذكاء الاصطناعي – جامعة المنوفية', 'Faculty of AI – Menoufia University'),
                      style: const TextStyle(color: Colors.white70),
                    ),
                    if (u.priority) ...[
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.amber,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          tr('حساب له أولوية في الطابور', 'Priority account'),
                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            if (active != null) ...[
              _activeCard(active),
              const SizedBox(height: 16),
            ],
            Text(
              tr('الخدمات المتاحة', 'Available services'),
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.15,
              children: [
                for (final p in app.places) _placeCard(context, p),
              ],
            ),
          ],
        );
      },
    );
  }

  Widget _activeCard(Ticket t) {
    final s = app.serviceById(t.serviceId);
    return AppCard(
      onTap: onGoTicket,
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: kPrimary,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              t.code,
              style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(tr('تذكرتك الحالية', 'Your current ticket'),
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                Text(s.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 4),
                StatusChip(t.status),
              ],
            ),
          ),
          const Icon(Icons.chevron_right),
        ],
      ),
    );
  }

  Widget _placeCard(BuildContext context, Place p) {
    final n = app.waitingInPlace(p.id);
    return AppCard(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => PlaceServicesScreen(place: p, onBooked: onGoTicket),
          ),
        );
      },
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircleAvatar(
            radius: 26,
            backgroundColor: kPrimary.withAlpha(25),
            child: Icon(p.icon, color: kPrimary, size: 28),
          ),
          const SizedBox(height: 10),
          Text(
            p.name,
            textAlign: TextAlign.center,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 2),
          Text(
            tr('$n منتظر الآن', '$n waiting now'),
            style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
          ),
        ],
      ),
    );
  }
}

// ===============================================================
// خدمات مكان معيّن + الحجز
// ===============================================================
class PlaceServicesScreen extends StatelessWidget {
  final Place place;
  final VoidCallback onBooked;
  const PlaceServicesScreen({super.key, required this.place, required this.onBooked});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final u = app.me;
        if (u == null) return const Scaffold();
        final services = app.servicesOf(place.id);
        final hasActive = app.activeTicketOf(u.id) != null;
        return Scaffold(
          appBar: AppBar(title: Text(place.name)),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              if (hasActive)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: AppCard(
                    color: const Color(0xFFFFF4E0),
                    child: Row(
                      children: [
                        Icon(Icons.info_outline, color: Colors.orange.shade800),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(tr(
                            'لديك تذكرة فعّالة. يمكنك حجز تذكرة واحدة فقط في نفس الوقت.',
                            'You have an active ticket. Only one active ticket is allowed at a time.',
                          )),
                        ),
                      ],
                    ),
                  ),
                ),
              for (final s in services)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: _serviceTile(context, s, u, hasActive),
                ),
            ],
          ),
        );
      },
    );
  }

  Widget _serviceTile(BuildContext context, Service s, AppUser u, bool hasActive) {
    final waiting = app.queueOf(s.id).length;
    final est = app.estWaitNew(s, u.priority);
    String stateText = tr('مفتوحة', 'Open');
    Color stateColor = Colors.green.shade700;
    if (!s.open) {
      stateText = tr('مغلقة', 'Closed');
      stateColor = Colors.grey.shade700;
    } else if (s.paused) {
      stateText = tr('متوقفة مؤقتًا', 'Paused');
      stateColor = Colors.orange.shade800;
    }
    final enabled = s.open && !hasActive;
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(s.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: stateColor.withAlpha(30),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(stateText,
                    style: TextStyle(color: stateColor, fontWeight: FontWeight.bold, fontSize: 12)),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 16,
            runSpacing: 6,
            children: [
              InfoPill(icon: Icons.people, text: tr('$waiting منتظر', '$waiting waiting')),
              InfoPill(icon: Icons.timer, text: tr('انتظار متوقع ~ $est د', 'Est. wait ~ $est min')),
              InfoPill(icon: Icons.schedule, text: tr('متوسط الخدمة ${s.avgMinutes} د', 'Avg ${s.avgMinutes} min')),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: enabled ? () => _book(context, s) : null,
              child: Text(tr('احجز تذكرة', 'Book a ticket')),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _book(BuildContext context, Service s) async {
    final u = app.me!;
    final ahead = app.aheadForNew(s, u.priority);
    final wait = app.estWaitNew(s, u.priority);
    final ok = await confirmDialog(
      context,
      tr('تأكيد الحجز', 'Confirm booking'),
      tr(
        'الخدمة: ${s.nameAr}\nعدد الأشخاص أمامك: $ahead\nالوقت المتوقع: $wait دقيقة',
        'Service: ${s.nameEn}\nPeople ahead: $ahead\nEstimated wait: $wait min',
      ),
      confirmText: tr('احجز', 'Book'),
    );
    if (!ok || !context.mounted) return;
    final err = app.book(s);
    if (err != null) {
      snack(context, err);
      return;
    }
    Navigator.pop(context);
    onBooked();
  }
}

// ===============================================================
// تذكرتي: الرقم + الترتيب + الوقت + الحالة + الوصول + الإلغاء
// ===============================================================
class MyTicketScreen extends StatelessWidget {
  final VoidCallback onGoHome;
  const MyTicketScreen({super.key, required this.onGoHome});

  Widget _gap(Widget w) => Padding(padding: const EdgeInsets.only(bottom: 12), child: w);

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final u = app.me!;
        final t = app.activeTicketOf(u.id);
        if (t == null) {
          return EmptyState(
            icon: Icons.confirmation_number_outlined,
            title: tr('لا توجد تذكرة حالية', 'No active ticket'),
            subtitle: tr('اختر خدمة من الرئيسية لحجز تذكرة.', 'Pick a service from Home to get a ticket.'),
            buttonText: tr('تصفّح الخدمات', 'Browse services'),
            onPressed: onGoHome,
          );
        }
        final s = app.serviceById(t.serviceId);
        final p = app.placeById(s.placeId);
        final waiting = t.status == TicketStatus.waiting;
        final called = t.status == TicketStatus.called;
        final serving = t.status == TicketStatus.serving;
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _gap(_ticketCard(t, s, p)),
            if (waiting) _gap(_waitingInfo(t)),
            if (waiting && s.paused)
              _gap(_banner(
                color: Colors.orange.shade800,
                icon: Icons.pause_circle,
                children: [
                  Text(
                    tr('الطابور متوقف مؤقتًا من الموظف. سيستأنف قريبًا.', 'The queue is paused by staff. It will resume soon.'),
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
              )),
            if (waiting)
              _gap(Text(
                tr('سيصلك إشعار عندما يتبقى حوالي $kNotifyMinutes دقائق على دورك.',
                    'You will be notified when about $kNotifyMinutes minutes remain.'),
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey.shade700, fontSize: 13),
              )),
            if (called) _gap(_calledBanner(t, s, p)),
            if (serving)
              _gap(_banner(
                color: Colors.green.shade700,
                icon: Icons.support_agent,
                children: [
                  Text(
                    tr('جارٍ خدمتك الآن عند شباك ${s.desk}.', 'You are being served now at window ${s.desk}.'),
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
              )),
            if (waiting || called) _gap(_arrivalCard(context, t, p)),
            if (waiting || called) _gap(_cancelButton(context, t)),
            if (kShowDemoTools) _gap(_demoTools(t, s)),
          ],
        );
      },
    );
  }

  Widget _ticketCard(Ticket t, Service s, Place p) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [kPrimary, kPrimaryLight],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        children: [
          Text(
            s.name,
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
          ),
          Text(p.name, style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 14),
          Text(tr('رقم تذكرتك', 'Your ticket number'), style: const TextStyle(color: Colors.white70)),
          Text(
            t.code,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 56,
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              statusLabel(t.status),
              style: TextStyle(color: statusColor(t.status), fontWeight: FontWeight.bold),
            ),
          ),
          if (t.priority) ...[
            const SizedBox(height: 8),
            Text(tr('★ تذكرة ذات أولوية', '★ Priority ticket'), style: const TextStyle(color: Colors.amber)),
          ],
        ],
      ),
    );
  }

  Widget _waitingInfo(Ticket t) {
    final ahead = app.peopleAhead(t);
    final wait = app.estWait(t);
    return Row(
      children: [
        Expanded(child: _stat(Icons.people, '$ahead', tr('أمامك', 'Ahead of you'))),
        const SizedBox(width: 8),
        Expanded(child: _stat(Icons.timer, '$wait', tr('دقيقة متوقعة', 'min estimated'))),
        const SizedBox(width: 8),
        Expanded(child: _stat(Icons.format_list_numbered, '${ahead + 1}', tr('ترتيبك', 'Your position'))),
      ],
    );
  }

  Widget _stat(IconData icon, String value, String label) {
    return AppCard(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
      child: Column(
        children: [
          Icon(icon, color: kPrimary),
          const SizedBox(height: 6),
          Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 11, color: Colors.grey.shade700),
          ),
        ],
      ),
    );
  }

  Widget _banner({required Color color, required IconData icon, required List<Widget> children}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withAlpha(25),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withAlpha(90)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 28),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children),
          ),
        ],
      ),
    );
  }

  Widget _calledBanner(Ticket t, Service s, Place p) {
    return _banner(
      color: Colors.green.shade700,
      icon: Icons.campaign,
      children: [
        Text(
          tr('حان دورك! توجّه إلى شباك ${s.desk} – ${p.nameAr}', 'Your turn! Go to window ${s.desk} – ${p.nameEn}'),
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        const SizedBox(height: 6),
        if (!t.arrived && t.calledAt != null)
          Row(
            children: [
              Text(tr('المهلة المتبقية: ', 'Time left: ')),
              CountdownText(
                from: t.calledAt!,
                seconds: kGraceSeconds,
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: Colors.red.shade700),
              ),
            ],
          )
        else
          Text(tr('تم تأكيد وصولك، بانتظار الموظف.', 'Arrival confirmed, waiting for the staff.')),
      ],
    );
  }

  Widget _arrivalCard(BuildContext context, Ticket t, Place p) {
    if (t.arrived) {
      return AppCard(
        child: Row(
          children: [
            Icon(Icons.check_circle, color: Colors.green.shade700),
            const SizedBox(width: 8),
            Expanded(child: Text(tr('تم تأكيد وصولك إلى المكتب', 'Your arrival at the office is confirmed'))),
          ],
        ),
      );
    }
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(tr('وصلت إلى المكتب؟', 'Arrived at the office?'),
              style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(
            tr('امسح رمز QR المعلّق على باب المكتب لتأكيد وصولك.', 'Scan the QR code on the office door to confirm your arrival.'),
            style: TextStyle(color: Colors.grey.shade700, fontSize: 13),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: FilledButton.tonalIcon(
              onPressed: () async {
                final ok = await Navigator.push<bool>(
                  context,
                  MaterialPageRoute(builder: (_) => QrScanScreen(place: p)),
                );
                if (ok == true) app.confirmArrival(t);
              },
              icon: const Icon(Icons.qr_code_scanner),
              label: Text(tr('وصلت – مسح QR', 'I arrived – scan QR')),
            ),
          ),
        ],
      ),
    );
  }

  Widget _cancelButton(BuildContext context, Ticket t) {
    return Center(
      child: TextButton.icon(
        onPressed: () async {
          final ok = await confirmDialog(
            context,
            tr('إلغاء التذكرة', 'Cancel ticket'),
            tr('هل تريد إلغاء تذكرتك ${t.code}؟', 'Do you want to cancel ticket ${t.code}?'),
            confirmText: tr('نعم، إلغاء', 'Yes, cancel'),
          );
          if (ok) app.cancel(t);
        },
        icon: Icon(Icons.cancel_outlined, color: Colors.red.shade700),
        label: Text(tr('إلغاء التذكرة', 'Cancel ticket'), style: TextStyle(color: Colors.red.shade700)),
      ),
    );
  }

  Widget _demoTools(Ticket t, Service s) {
    final mine = t.status == TicketStatus.called || t.status == TicketStatus.serving;
    return AppCard(
      color: const Color(0xFFFFF8E1),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.science, color: Colors.orange.shade800),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  tr('أدوات العرض التجريبي (لا تظهر في النسخة الحقيقية)', 'Demo tools (not in the real version)'),
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            tr('بدون سيرفر، الطالب والموظف على نفس الجهاز. استخدم الزر لمحاكاة تقدّم الطابور.',
                'There is no server, so student and staff share one device. Use the button to simulate queue progress.'),
            style: const TextStyle(fontSize: 12),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () {
                if (mine) {
                  app.demoFinish(t);
                } else {
                  app.demoStep(s);
                }
              },
              icon: Icon(mine ? Icons.done_all : Icons.skip_next),
              label: Text(mine
                  ? tr('محاكاة: الموظف ينهي خدمتي', 'Simulate: staff completes my service')
                  : tr('محاكاة: الموظف يخدم الطالب التالي', 'Simulate: staff serves the next student')),
            ),
          ),
        ],
      ),
    );
  }
}

// ===============================================================
// شاشة مسح QR (محاكاة بدون كاميرا)
// ===============================================================
class QrScanScreen extends StatefulWidget {
  final Place place;
  const QrScanScreen({super.key, required this.place});

  @override
  State<QrScanScreen> createState() => _QrScanScreenState();
}

class _QrScanScreenState extends State<QrScanScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text(tr('مسح رمز QR', 'Scan QR code')),
        backgroundColor: Colors.black,
      ),
      body: Column(
        children: [
          Expanded(
            child: Center(
              child: SizedBox(
                width: 260,
                height: 260,
                child: Stack(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.white, width: 3),
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                    AnimatedBuilder(
                      animation: _c,
                      builder: (context, _) => Positioned(
                        top: 10 + _c.value * 230,
                        left: 12,
                        right: 12,
                        child: Container(height: 3, color: Colors.greenAccent),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                Text(
                  tr('وجّه الكاميرا نحو رمز QR المعلّق على باب ${widget.place.nameAr}',
                      'Point the camera at the QR code on the door of ${widget.place.nameEn}'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white70),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: () => Navigator.pop(context, true),
                    child: Text(tr('محاكاة: تم مسح الرمز', 'Simulate: code scanned')),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ===============================================================
// السجل
// ===============================================================
class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final list = app.historyOf(app.me!.id);
        if (list.isEmpty) {
          return EmptyState(
            icon: Icons.history,
            title: tr('لا يوجد سجل بعد', 'No history yet'),
            subtitle: tr('ستظهر هنا تذاكرك السابقة.', 'Your past tickets will appear here.'),
          );
        }
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            for (final t in list)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: AppCard(
                  child: Row(
                    children: [
                      Text(t.code, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(app.serviceById(t.serviceId).name, maxLines: 1, overflow: TextOverflow.ellipsis),
                            Text(
                              fmtDateTime(t.createdAt),
                              style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
                            ),
                          ],
                        ),
                      ),
                      StatusChip(t.status),
                    ],
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}

// ===============================================================
// حسابي
// ===============================================================
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  Widget _row(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(icon, color: kPrimary, size: 20),
          const SizedBox(width: 10),
          Text('$label: ', style: TextStyle(color: Colors.grey.shade700)),
          Expanded(child: Text(value, style: const TextStyle(fontWeight: FontWeight.bold))),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final u = app.me!;
        final nid = u.nationalId;
        final masked = nid.length > 4 ? '**********${nid.substring(nid.length - 4)}' : nid;
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Center(
              child: CircleAvatar(
                radius: 40,
                backgroundColor: kPrimary,
                child: Text(
                  u.name.isNotEmpty ? u.name.substring(0, 1) : '?',
                  style: const TextStyle(color: Colors.white, fontSize: 32),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Center(
              child: Text(u.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 16),
            AppCard(
              child: Column(
                children: [
                  _row(Icons.badge_outlined, tr('الرقم القومي', 'National ID'), masked),
                  _row(Icons.tag, tr('الرقم الأكاديمي', 'Academic ID'), u.academicId),
                  _row(Icons.school, tr('الكلية', 'Faculty'), tr('الذكاء الاصطناعي – المنوفية', 'AI – Menoufia')),
                ],
              ),
            ),
            const SizedBox(height: 12),
            AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(tr('اللغة', 'Language'), style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  SegmentedButton<bool>(
                    segments: const <ButtonSegment<bool>>[
                      ButtonSegment<bool>(value: true, label: Text('العربية')),
                      ButtonSegment<bool>(value: false, label: Text('English')),
                    ],
                    selected: {app.isAr},
                    onSelectionChanged: (Set<bool> s) => app.setLang(s.first),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            AppCard(
              color: const Color(0xFFE8F1FB),
              child: Text(
                tr('هذه نسخة تجريبية ببيانات وهمية. الحجز والإشعارات تعمل داخل التطبيق فقط، وسيتم ربطها بنظام الكلية لاحقًا.',
                    'This is a prototype with demo data. Booking and notifications work inside the app only and will be connected to the faculty system later.'),
                style: const TextStyle(fontSize: 13),
              ),
            ),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: () async {
                final ok = await confirmDialog(
                  context,
                  tr('تسجيل الخروج', 'Log out'),
                  tr('هل تريد تسجيل الخروج؟', 'Do you want to log out?'),
                );
                if (ok) app.logout();
              },
              icon: Icon(Icons.logout, color: Colors.red.shade700),
              label: Text(tr('تسجيل الخروج', 'Log out'), style: TextStyle(color: Colors.red.shade700)),
            ),
          ],
        );
      },
    );
  }
}

// ===============================================================
// الإشعارات
// ===============================================================
class NoticesScreen extends StatelessWidget {
  const NoticesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final u = app.me;
        final list = u == null ? <Notice>[] : app.noticesOf(u.id);
        return Scaffold(
          appBar: AppBar(title: Text(tr('الإشعارات', 'Notifications'))),
          body: list.isEmpty
              ? EmptyState(
                  icon: Icons.notifications_none,
                  title: tr('لا توجد إشعارات', 'No notifications'),
                )
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    for (final n in list)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: AppCard(
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Icon(Icons.notifications_active, color: kPrimary),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(n.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                                    const SizedBox(height: 2),
                                    Text(n.body),
                                    const SizedBox(height: 4),
                                    Text(
                                      fmtTime(n.time),
                                      style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
        );
      },
    );
  }
}
