import 'dart:async';
import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'state.dart';

const Color kPrimary = Color(0xFF1E5AA8);
const Color kPrimaryLight = Color(0xFF3B82D6);
const Color kBg = Color(0xFFF4F6FB);
const Color kBorder = Color(0xFFE3E8F2);

ThemeData buildTheme() {
  return ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(seedColor: kPrimary),
    scaffoldBackgroundColor: kBg,
    appBarTheme: const AppBarTheme(
      backgroundColor: kPrimary,
      foregroundColor: Colors.white,
      centerTitle: true,
    ),
  );
}

// ---------------------------------------------------------------
// دوال مساعدة
// ---------------------------------------------------------------
String fmtTime(DateTime d) =>
    '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

String fmtDateTime(DateTime d) => '${d.day}/${d.month}/${d.year}  ${fmtTime(d)}';

void snack(BuildContext context, String msg) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
}

String statusLabel(TicketStatus s) {
  if (s == TicketStatus.waiting) return tr('في الانتظار', 'Waiting');
  if (s == TicketStatus.called) return tr('تم النداء', 'Called');
  if (s == TicketStatus.serving) return tr('جارٍ الخدمة', 'Being served');
  if (s == TicketStatus.completed) return tr('مكتملة', 'Completed');
  if (s == TicketStatus.cancelled) return tr('ملغاة', 'Cancelled');
  return tr('فائتة', 'Missed');
}

Color statusColor(TicketStatus s) {
  if (s == TicketStatus.waiting) return const Color(0xFF1E5AA8);
  if (s == TicketStatus.called) return const Color(0xFFE65100);
  if (s == TicketStatus.serving) return const Color(0xFF2E7D32);
  if (s == TicketStatus.completed) return const Color(0xFF2E7D32);
  if (s == TicketStatus.cancelled) return const Color(0xFF757575);
  return const Color(0xFFC62828);
}

Future<bool> confirmDialog(
  BuildContext context,
  String title,
  String message, {
  String? confirmText,
}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: Text(tr('رجوع', 'Back')),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(ctx, true),
          child: Text(confirmText ?? tr('تأكيد', 'Confirm')),
        ),
      ],
    ),
  );
  return r ?? false;
}

// ---------------------------------------------------------------
// عناصر مشتركة
// ---------------------------------------------------------------
class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final Color? color;

  const AppCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.onTap,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: color ?? Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: kBorder),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(padding: padding, child: child),
      ),
    );
  }
}

class StatusChip extends StatelessWidget {
  final TicketStatus status;
  const StatusChip(this.status, {super.key});

  @override
  Widget build(BuildContext context) {
    final c = statusColor(status);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: c.withAlpha(30),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        statusLabel(status),
        style: TextStyle(color: c, fontWeight: FontWeight.bold, fontSize: 12),
      ),
    );
  }
}

class InfoPill extends StatelessWidget {
  final IconData icon;
  final String text;
  const InfoPill({super.key, required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 16, color: Colors.grey.shade700),
        const SizedBox(width: 4),
        Text(text, style: TextStyle(color: Colors.grey.shade800, fontSize: 13)),
      ],
    );
  }
}

class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final String? buttonText;
  final VoidCallback? onPressed;

  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    this.subtitle,
    this.buttonText,
    this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 72, color: Colors.grey.shade400),
            const SizedBox(height: 16),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            if (subtitle != null) ...[
              const SizedBox(height: 8),
              Text(
                subtitle!,
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey.shade600),
              ),
            ],
            if (buttonText != null) ...[
              const SizedBox(height: 20),
              FilledButton(onPressed: onPressed, child: Text(buttonText!)),
            ],
          ],
        ),
      ),
    );
  }
}

class LogoMark extends StatelessWidget {
  final double size;
  const LogoMark({super.key, this.size = 72});

  @override
  Widget build(BuildContext context) {
    // استبدليها بشعار الكلية لما تحطيه في assets
    return Container(
      width: size,
      height: size,
      decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
      child: Icon(Icons.confirmation_number, size: size * 0.5, color: kPrimary),
    );
  }
}

class LangButton extends StatelessWidget {
  final Color? color;
  const LangButton({super.key, this.color});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final c = color ?? Colors.white;
        return TextButton.icon(
          onPressed: () => app.setLang(!app.isAr),
          icon: Icon(Icons.language, color: c, size: 18),
          label: Text(app.isAr ? 'English' : 'عربي', style: TextStyle(color: c)),
        );
      },
    );
  }
}

class LogoutButton extends StatelessWidget {
  const LogoutButton({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        return IconButton(
          icon: const Icon(Icons.logout),
          tooltip: tr('تسجيل الخروج', 'Log out'),
          onPressed: () async {
            final ok = await confirmDialog(
              context,
              tr('تسجيل الخروج', 'Log out'),
              tr('هل تريد تسجيل الخروج؟', 'Do you want to log out?'),
            );
            if (ok) app.logout();
          },
        );
      },
    );
  }
}

/// عدّاد تنازلي (mm:ss) من لحظة معينة.
class CountdownText extends StatefulWidget {
  final DateTime from;
  final int seconds;
  final TextStyle? style;

  const CountdownText({super.key, required this.from, required this.seconds, this.style});

  @override
  State<CountdownText> createState() => _CountdownTextState();
}

class _CountdownTextState extends State<CountdownText> {
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    int left = widget.seconds - DateTime.now().difference(widget.from).inSeconds;
    if (left < 0) left = 0;
    final m = (left ~/ 60).toString().padLeft(2, '0');
    final s = (left % 60).toString().padLeft(2, '0');
    return Text('$m:$s', style: widget.style);
  }
}

/// رمز QR للمكتب (باستخدام حزمة qr_flutter).
class OfficeQr extends StatelessWidget {
  final String data;
  final double size;
  const OfficeQr({super.key, required this.data, this.size = 200});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: QrImageView(
        data: data,
        version: QrVersions.auto,
        size: size,
        backgroundColor: Colors.white,
      ),
    );
  }
}
