import 'package:flutter/material.dart';
import 'state.dart';
import 'widgets.dart';

class AdminShell extends StatefulWidget {
  const AdminShell({super.key});

  @override
  State<AdminShell> createState() => _AdminShellState();
}

class _AdminShellState extends State<AdminShell> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final pages = <Widget>[
          const StatsTab(),
          const ServicesTab(),
          const EmployeesTab(),
        ];
        return Scaffold(
          appBar: AppBar(
            title: Text(tr('لوحة الإدارة', 'Admin Dashboard')),
            actions: const [LangButton(), LogoutButton()],
          ),
          body: pages[_tab],
          bottomNavigationBar: NavigationBar(
            selectedIndex: _tab,
            onDestinationSelected: (i) => setState(() => _tab = i),
            destinations: [
              NavigationDestination(
                icon: const Icon(Icons.bar_chart),
                label: tr('الإحصائيات', 'Statistics'),
              ),
              NavigationDestination(
                icon: const Icon(Icons.room_service_outlined),
                selectedIcon: const Icon(Icons.room_service),
                label: tr('الخدمات', 'Services'),
              ),
              NavigationDestination(
                icon: const Icon(Icons.people_outline),
                selectedIcon: const Icon(Icons.people),
                label: tr('الموظفون', 'Employees'),
              ),
            ],
          ),
        );
      },
    );
  }
}

// ===============================================================
// الإحصائيات
// ===============================================================
class StatsTab extends StatelessWidget {
  const StatsTab({super.key});

  Widget _stat(IconData icon, String value, String label, Color color) {
    return AppCard(
      child: Column(
        children: [
          Icon(icon, color: color, size: 28),
          const SizedBox(height: 6),
          Text(value, style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: color)),
          Text(label, textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.grey.shade700)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final today = app.todayTickets;
        final total = today.length;
        final done = app.countToday(TicketStatus.completed);
        final waiting = app.countToday(TicketStatus.waiting);
        final lost = app.countToday(TicketStatus.cancelled) + app.countToday(TicketStatus.missed);
        final avg = app.avgWaitMinutes.toStringAsFixed(1);
        final busiest = app.busiestService;

        int maxC = 1;
        final counts = <String, int>{};
        for (final s in app.services) {
          final c = today.where((t) => t.serviceId == s.id).length;
          counts[s.id] = c;
          if (c > maxC) maxC = c;
        }

        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(
              tr('إحصائيات اليوم', "Today's statistics"),
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(child: _stat(Icons.confirmation_number, '$total', tr('إجمالي التذاكر', 'Total tickets'), kPrimary)),
                const SizedBox(width: 12),
                Expanded(child: _stat(Icons.check_circle, '$done', tr('تمت خدمتها', 'Completed'), Colors.green.shade700)),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _stat(Icons.hourglass_bottom, '$waiting', tr('في الانتظار الآن', 'Waiting now'), Colors.orange.shade800)),
                const SizedBox(width: 12),
                Expanded(child: _stat(Icons.cancel, '$lost', tr('ملغاة / فائتة', 'Cancelled / missed'), Colors.red.shade700)),
              ],
            ),
            const SizedBox(height: 12),
            AppCard(
              child: Row(
                children: [
                  const Icon(Icons.timer, color: kPrimary),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(tr('متوسط وقت الانتظار الفعلي', 'Average actual waiting time')),
                  ),
                  Text(
                    tr('$avg دقيقة', '$avg min'),
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                ],
              ),
            ),
            if (busiest != null) ...[
              const SizedBox(height: 12),
              AppCard(
                child: Row(
                  children: [
                    Icon(Icons.local_fire_department, color: Colors.orange.shade800),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(tr('أكثر خدمة ازدحامًا الآن: ${busiest.nameAr}', 'Busiest service now: ${busiest.nameEn}')),
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 20),
            Text(
              tr('التذاكر حسب الخدمة', 'Tickets per service'),
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            AppCard(
              child: Column(
                children: [
                  for (final s in app.services)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      child: Row(
                        children: [
                          SizedBox(
                            width: 110,
                            child: Text(s.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
                          ),
                          Expanded(
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(6),
                              child: LinearProgressIndicator(
                                value: (counts[s.id] ?? 0) / maxC,
                                minHeight: 12,
                                backgroundColor: kBorder,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          SizedBox(
                            width: 24,
                            child: Text('${counts[s.id] ?? 0}', style: const TextStyle(fontWeight: FontWeight.bold)),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}

// ===============================================================
// إدارة الخدمات
// ===============================================================
class ServicesTab extends StatelessWidget {
  const ServicesTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        return Scaffold(
          backgroundColor: kBg,
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => _addService(context),
            icon: const Icon(Icons.add),
            label: Text(tr('إضافة خدمة', 'Add service')),
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
            children: [
              for (final p in app.places) ...[
                Padding(
                  padding: const EdgeInsets.only(top: 6, bottom: 8),
                  child: Row(
                    children: [
                      Icon(p.icon, color: kPrimary, size: 20),
                      const SizedBox(width: 8),
                      Text(p.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
                for (final s in app.servicesOf(p.id))
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: AppCard(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(s.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                                Text(
                                  tr('متوسط الخدمة ${s.avgMinutes} د · رمز ${s.code}', 'Avg ${s.avgMinutes} min · code ${s.code}'),
                                  style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                            tooltip: tr('تعديل', 'Edit'),
                            icon: const Icon(Icons.edit_outlined),
                            onPressed: () => _editService(context, s),
                          ),
                          Switch(
                            value: s.open,
                            onChanged: (v) => app.setServiceOpen(s, v),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ],
          ),
        );
      },
    );
  }

  void _editService(BuildContext context, Service s) {
    final ar = TextEditingController(text: s.nameAr);
    final en = TextEditingController(text: s.nameEn);
    final avg = TextEditingController(text: '${s.avgMinutes}');
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr('تعديل الخدمة', 'Edit service')),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: ar, decoration: InputDecoration(labelText: tr('الاسم بالعربية', 'Arabic name'))),
              TextField(controller: en, decoration: InputDecoration(labelText: tr('الاسم بالإنجليزية', 'English name'))),
              TextField(
                controller: avg,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: tr('متوسط وقت الخدمة (دقيقة)', 'Avg service time (min)')),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(tr('إلغاء', 'Cancel'))),
          FilledButton(
            onPressed: () {
              app.updateService(s, ar.text.trim(), en.text.trim(), int.tryParse(avg.text.trim()));
              Navigator.pop(ctx);
            },
            child: Text(tr('حفظ', 'Save')),
          ),
        ],
      ),
    );
  }

  void _addService(BuildContext context) {
    String pid = app.places.first.id;
    final ar = TextEditingController();
    final en = TextEditingController();
    final avg = TextEditingController(text: '5');
    showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSt) => AlertDialog(
          title: Text(tr('إضافة خدمة', 'Add service')),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(tr('المكان', 'Place')),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 6,
                  children: [
                    for (final p in app.places)
                      ChoiceChip(
                        label: Text(p.name),
                        selected: pid == p.id,
                        onSelected: (_) => setSt(() => pid = p.id),
                      ),
                  ],
                ),
                TextField(controller: ar, decoration: InputDecoration(labelText: tr('الاسم بالعربية', 'Arabic name'))),
                TextField(controller: en, decoration: InputDecoration(labelText: tr('الاسم بالإنجليزية', 'English name'))),
                TextField(
                  controller: avg,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(labelText: tr('متوسط وقت الخدمة (دقيقة)', 'Avg service time (min)')),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: Text(tr('إلغاء', 'Cancel'))),
            FilledButton(
              onPressed: () {
                final a = ar.text.trim();
                if (a.isEmpty) return;
                final e = en.text.trim().isEmpty ? a : en.text.trim();
                app.addService(pid, a, e, int.tryParse(avg.text.trim()) ?? 5);
                Navigator.pop(ctx);
              },
              child: Text(tr('إضافة', 'Add')),
            ),
          ],
        ),
      ),
    );
  }
}

// ===============================================================
// إدارة الموظفين
// ===============================================================
class EmployeesTab extends StatelessWidget {
  const EmployeesTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final list = app.employees;
        return Scaffold(
          backgroundColor: kBg,
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => _addEmployee(context),
            icon: const Icon(Icons.person_add),
            label: Text(tr('إضافة موظف', 'Add employee')),
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
            children: [
              for (final u in list)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: AppCard(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    child: Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: kPrimary.withAlpha(25),
                          child: const Icon(Icons.badge, color: kPrimary),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(u.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                              Text(
                                '${u.academicId} · ${app.placeById(u.placeId ?? 'p1').name}',
                                style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
                              ),
                            ],
                          ),
                        ),
                        Switch(
                          value: u.active,
                          onChanged: (v) => app.setUserActive(u, v),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  void _addEmployee(BuildContext context) {
    String pid = app.places.first.id;
    String? err;
    final name = TextEditingController();
    final nid = TextEditingController();
    final code = TextEditingController();
    showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSt) => AlertDialog(
          title: Text(tr('إضافة موظف', 'Add employee')),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(tr('مكان العمل', 'Workplace')),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 6,
                  children: [
                    for (final p in app.places)
                      ChoiceChip(
                        label: Text(p.name),
                        selected: pid == p.id,
                        onSelected: (_) => setSt(() => pid = p.id),
                      ),
                  ],
                ),
                TextField(controller: name, decoration: InputDecoration(labelText: tr('اسم الموظف', 'Employee name'))),
                TextField(
                  controller: nid,
                  keyboardType: TextInputType.number,
                  maxLength: 14,
                  decoration: InputDecoration(labelText: tr('الرقم القومي (14 رقمًا)', 'National ID (14 digits)'), counterText: ''),
                ),
                TextField(controller: code, decoration: InputDecoration(labelText: tr('كود الموظف', 'Staff code'))),
                if (err != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(err!, style: TextStyle(color: Colors.red.shade700)),
                  ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: Text(tr('إلغاء', 'Cancel'))),
            FilledButton(
              onPressed: () {
                final e = app.addEmployee(name.text.trim(), nid.text.trim(), code.text.trim(), pid);
                if (e != null) {
                  setSt(() => err = e);
                } else {
                  Navigator.pop(ctx);
                }
              },
              child: Text(tr('إضافة', 'Add')),
            ),
          ],
        ),
      ),
    );
  }
}
