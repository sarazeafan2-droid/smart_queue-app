import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'admin.dart';
import 'employee.dart';
import 'login.dart';
import 'state.dart';
import 'student.dart';
import 'widgets.dart';

void main() {
  runApp(const SmartQueueApp());
}

class SmartQueueApp extends StatelessWidget {
  const SmartQueueApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Smart Queue',
          theme: buildTheme(),
          locale: Locale(app.isAr ? 'ar' : 'en'),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          home: const RootGate(),
        );
      },
    );
  }
}

/// بوابة التطبيق: شاشة البداية ثم الدخول ثم الواجهة حسب نوع المستخدم.
class RootGate extends StatefulWidget {
  const RootGate({super.key});

  @override
  State<RootGate> createState() => _RootGateState();
}

class _RootGateState extends State<RootGate> {
  bool _splashDone = false;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1500), () {
      if (mounted) setState(() => _splashDone = true);
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        if (!_splashDone) return const SplashScreen();
        final u = app.me;
        if (u == null) return const LoginScreen();
        if (u.role == Role.student) return const StudentShell();
        if (u.role == Role.employee) return const EmployeeShell();
        return const AdminShell();
      },
    );
  }
}
