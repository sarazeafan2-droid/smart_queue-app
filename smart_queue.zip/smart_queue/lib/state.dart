import 'dart:async';
import 'package:flutter/material.dart';

/// مهلة حضور الطالب بعد النداء بالثواني (3 دقائق).
/// وقت العرض ممكن تخليها 20 مثلا عشان تشوفي التخطي التلقائي بسرعة.
const int kGraceSeconds = 180;

/// الإشعار بيوصل لما يفضل على الدور حوالي كذا دقيقة.
const int kNotifyMinutes = 5;

/// أدوات المحاكاة في شاشة تذكرة الطالب (للعرض فقط). خليها false لو مش عايزاها.
const bool kShowDemoTools = true;

enum Role { student, employee, admin }

enum TicketStatus { waiting, called, serving, completed, cancelled, missed }

/// ترجمة سريعة: عربي / إنجليزي
String tr(String ar, String en) => app.isAr ? ar : en;

/// الحالة العامة للتطبيق (بيانات تجريبية داخل الذاكرة، بدون سيرفر).
final AppState app = AppState();

class Place {
  final String id;
  final String nameAr;
  final String nameEn;
  final IconData icon;
  Place(this.id, this.nameAr, this.nameEn, this.icon);
  String get name => tr(nameAr, nameEn);
}

class Service {
  final String id;
  final String placeId;
  final String code;
  String nameAr;
  String nameEn;
  int avgMinutes;
  bool open;
  bool paused;
  int desk;
  int counter;

  Service({
    required this.id,
    required this.placeId,
    required this.code,
    required this.nameAr,
    required this.nameEn,
    required this.avgMinutes,
    this.open = true,
    this.paused = false,
    this.desk = 1,
    this.counter = 10,
  });

  String get name => tr(nameAr, nameEn);
}

class AppUser {
  final String id;
  final String nameAr;
  final String nameEn;
  final String nationalId;
  final String academicId;
  final Role role;
  final bool priority;
  final String? placeId;
  bool active;

  AppUser({
    required this.id,
    required this.nameAr,
    required this.nameEn,
    required this.nationalId,
    required this.academicId,
    required this.role,
    this.priority = false,
    this.placeId,
    this.active = true,
  });

  String get name => tr(nameAr, nameEn);
}

class Ticket {
  final String id;
  final String serviceId;
  final String code;
  final int number;
  final String studentId;
  final bool priority;
  final DateTime createdAt;
  TicketStatus status;
  bool arrived;
  bool notified;
  DateTime? calledAt;
  DateTime? startedAt;
  DateTime? endedAt;

  Ticket({
    required this.id,
    required this.serviceId,
    required this.code,
    required this.number,
    required this.studentId,
    required this.priority,
    required this.createdAt,
    this.status = TicketStatus.waiting,
    this.arrived = false,
    this.notified = false,
  });

  bool get isActive =>
      status == TicketStatus.waiting ||
      status == TicketStatus.called ||
      status == TicketStatus.serving;
}

class Notice {
  final String userId;
  final String titleAr;
  final String titleEn;
  final String bodyAr;
  final String bodyEn;
  final DateTime time;
  bool read;

  Notice({
    required this.userId,
    required this.titleAr,
    required this.titleEn,
    required this.bodyAr,
    required this.bodyEn,
    required this.time,
    this.read = false,
  });

  String get title => tr(titleAr, titleEn);
  String get body => tr(bodyAr, bodyEn);
}

class AppState extends ChangeNotifier {
  bool isAr = true;
  AppUser? me;
  int _seq = 1;
  Timer? _timer;

  final List<Place> places = [
    Place('p1', 'شؤون الطلبة', 'Student Affairs', Icons.school),
    Place('p2', 'الخزنة', 'Cashier', Icons.account_balance_wallet),
    Place('p3', 'المعامل', 'Labs', Icons.science),
    Place('p4', 'مكتب العميد', "Dean's Office", Icons.business_center),
  ];

  final List<Service> services = [
    Service(id: 's1', placeId: 'p1', code: 'A', nameAr: 'بيان حالة / إثبات قيد', nameEn: 'Enrollment Certificate', avgMinutes: 5),
    Service(id: 's2', placeId: 'p1', code: 'B', nameAr: 'طلب شهادة أو مستند', nameEn: 'Document Request', avgMinutes: 8),
    Service(id: 's3', placeId: 'p2', code: 'C', nameAr: 'دفع المصروفات', nameEn: 'Fee Payment', avgMinutes: 4),
    Service(id: 's4', placeId: 'p2', code: 'D', nameAr: 'استرداد مبلغ', nameEn: 'Refund', avgMinutes: 7),
    Service(id: 's5', placeId: 'p3', code: 'E', nameAr: 'حجز استخدام معمل', nameEn: 'Lab Booking', avgMinutes: 6),
    Service(id: 's6', placeId: 'p3', code: 'F', nameAr: 'استلام جهاز / عهدة', nameEn: 'Equipment Pickup', avgMinutes: 5),
    Service(id: 's7', placeId: 'p4', code: 'G', nameAr: 'مقابلة العميد', nameEn: 'Meet the Dean', avgMinutes: 10),
    Service(id: 's8', placeId: 'p4', code: 'H', nameAr: 'تقديم طلب أو شكوى', nameEn: 'Submit Request / Complaint', avgMinutes: 6),
  ];

  final List<AppUser> users = [];
  final List<Ticket> tickets = [];
  final List<Notice> notices = [];

  AppState() {
    _seed();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
  }

  // ---------------------------------------------------------------
  // بيانات تجريبية
  // ---------------------------------------------------------------
  void _seed() {
    const students = [
      ['أحمد محمد علي', 'Ahmed Mohamed Ali'],
      ['سارة محمود حسن', 'Sara Mahmoud Hassan'],
      ['مريم عبد الله', 'Mariam Abdullah'],
      ['عمر خالد', 'Omar Khaled'],
      ['ياسمين طارق', 'Yasmin Tarek'],
      ['كريم سامي', 'Karim Sami'],
      ['هدى إبراهيم', 'Hoda Ibrahim'],
      ['مصطفى أيمن', 'Mostafa Ayman'],
      ['نور حسام', 'Nour Hossam'],
      ['ليلى رضا', 'Laila Reda'],
    ];
    for (int i = 0; i < students.length; i++) {
      users.add(AppUser(
        id: 'u${_seq++}',
        nameAr: students[i][0],
        nameEn: students[i][1],
        nationalId: '2990101${1000001 + i}',
        academicId: '2025${(i + 1).toString().padLeft(4, '0')}',
        role: Role.student,
        priority: i == 1,
      ));
    }

    const staff = [
      ['أ. هالة سمير', 'Ms. Hala Samir', 'p1'],
      ['أ. محمد فتحي', 'Mr. Mohamed Fathy', 'p2'],
      ['م. نهى ربيع', 'Eng. Noha Rabie', 'p3'],
      ['أ. طارق عوض', 'Mr. Tarek Awad', 'p4'],
    ];
    for (int i = 0; i < staff.length; i++) {
      users.add(AppUser(
        id: 'u${_seq++}',
        nameAr: staff[i][0],
        nameEn: staff[i][1],
        nationalId: '2850101${2000001 + i}',
        academicId: 'EMP${(i + 1).toString().padLeft(3, '0')}',
        role: Role.employee,
        placeId: staff[i][2],
      ));
    }

    users.add(AppUser(
      id: 'u${_seq++}',
      nameAr: 'مدير النظام',
      nameEn: 'System Admin',
      nationalId: '27001013000001',
      academicId: 'ADM001',
      role: Role.admin,
    ));

    int k = 0;
    AppUser fake() {
      final u = users[2 + (k % 8)];
      k++;
      return u;
    }

    // تذاكر مكتملة اليوم (عشان الإحصائيات تبقى مليانة)
    for (final s in services) {
      for (int i = 0; i < 3; i++) {
        final t = _addTicket(s, fake(), minutesAgo: 200 - i * 25);
        t.arrived = true;
        t.status = TicketStatus.completed;
        t.calledAt = t.createdAt.add(Duration(minutes: 5 + i * 3));
        t.startedAt = t.calledAt;
        t.endedAt = t.startedAt!.add(Duration(minutes: s.avgMinutes));
      }
    }
    _addTicket(services[0], fake(), minutesAgo: 90).status = TicketStatus.cancelled;
    _addTicket(services[2], fake(), minutesAgo: 70).status = TicketStatus.cancelled;
    _addTicket(services[1], fake(), minutesAgo: 60).status = TicketStatus.missed;

    // سجل قديم للطالب الأول (امبارح)
    for (int i = 0; i < 2; i++) {
      final s = services[i == 0 ? 0 : 2];
      final t = _addTicket(s, users[0], minutesAgo: 24 * 60 + 40 + i * 30);
      t.arrived = true;
      t.status = TicketStatus.completed;
      t.calledAt = t.createdAt.add(const Duration(minutes: 6));
      t.startedAt = t.calledAt;
      t.endedAt = t.startedAt!.add(Duration(minutes: s.avgMinutes));
    }

    // ناس منتظرة دلوقتي
    const plan = {'s1': 4, 's2': 3, 's3': 6, 's4': 2, 's5': 3, 's6': 2, 's7': 2, 's8': 3};
    plan.forEach((sid, n) {
      final s = serviceById(sid);
      for (int i = 0; i < n; i++) {
        _addTicket(s, fake(), minutesAgo: 30 - i * 3);
      }
    });
  }

  Ticket _addTicket(Service s, AppUser u, {int minutesAgo = 0, bool notified = true}) {
    s.counter += 1;
    final t = Ticket(
      id: 't${_seq++}',
      serviceId: s.id,
      code: '${s.code}-${s.counter.toString().padLeft(3, '0')}',
      number: s.counter,
      studentId: u.id,
      priority: u.priority,
      createdAt: DateTime.now().subtract(Duration(minutes: minutesAgo)),
      notified: notified,
    );
    tickets.add(t);
    return t;
  }

  // ---------------------------------------------------------------
  // بحث وقوائم
  // ---------------------------------------------------------------
  Place placeById(String id) => places.firstWhere((p) => p.id == id);
  Service serviceById(String id) => services.firstWhere((s) => s.id == id);

  AppUser? userById(String id) {
    for (final u in users) {
      if (u.id == id) return u;
    }
    return null;
  }

  List<Service> servicesOf(String placeId) =>
      services.where((s) => s.placeId == placeId).toList();

  List<AppUser> get employees =>
      users.where((u) => u.role == Role.employee).toList();

  List<AppUser> get demoAccounts {
    final emps = employees.take(4).toList();
    final admin = users.firstWhere((u) => u.role == Role.admin);
    return [users[0], users[1], ...emps, admin];
  }

  // ---------------------------------------------------------------
  // الدخول واللغة
  // ---------------------------------------------------------------
  void setLang(bool arabic) {
    isAr = arabic;
    notifyListeners();
  }

  String? login(String nid, String aid) {
    final n = nid.trim();
    final a = aid.trim().toUpperCase();
    AppUser? found;
    for (final u in users) {
      if (u.nationalId == n && u.academicId.toUpperCase() == a) {
        found = u;
        break;
      }
    }
    if (found == null) {
      return tr('بيانات الدخول غير صحيحة', 'Incorrect login details');
    }
    if (!found.active) {
      return tr('هذا الحساب غير مفعّل', 'This account is disabled');
    }
    me = found;
    notifyListeners();
    return null;
  }

  void logout() {
    me = null;
    notifyListeners();
  }

  // ---------------------------------------------------------------
  // الطابور
  // ---------------------------------------------------------------
  int _cmp(Ticket a, Ticket b) {
    if (a.priority != b.priority) return a.priority ? -1 : 1;
    return a.number.compareTo(b.number);
  }

  List<Ticket> queueOf(String serviceId) {
    final l = tickets
        .where((t) => t.serviceId == serviceId && t.status == TicketStatus.waiting)
        .toList();
    l.sort(_cmp);
    return l;
  }

  Ticket? currentOf(String serviceId) {
    for (final t in tickets) {
      if (t.serviceId == serviceId &&
          (t.status == TicketStatus.called || t.status == TicketStatus.serving)) {
        return t;
      }
    }
    return null;
  }

  Ticket? activeTicketOf(String uid) {
    for (final t in tickets) {
      if (t.studentId == uid && t.isActive) return t;
    }
    return null;
  }

  List<Ticket> historyOf(String uid) {
    final l = tickets.where((t) => t.studentId == uid && !t.isActive).toList();
    l.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return l;
  }

  int waitingInPlace(String placeId) {
    int sum = 0;
    for (final s in servicesOf(placeId)) {
      sum += queueOf(s.id).length;
    }
    return sum;
  }

  int peopleAhead(Ticket t) {
    final i = queueOf(t.serviceId).indexOf(t);
    return i < 0 ? 0 : i;
  }

  int estWait(Ticket t) {
    final s = serviceById(t.serviceId);
    final cur = currentOf(s.id);
    return peopleAhead(t) * s.avgMinutes + (cur != null ? s.avgMinutes : 0);
  }

  int aheadForNew(Service s, bool priority) {
    final q = queueOf(s.id);
    if (priority) return q.where((t) => t.priority).length;
    return q.length;
  }

  int estWaitNew(Service s, bool priority) {
    final cur = currentOf(s.id);
    return aheadForNew(s, priority) * s.avgMinutes + (cur != null ? s.avgMinutes : 0);
  }

  // ---------------------------------------------------------------
  // إجراءات الطالب
  // ---------------------------------------------------------------
  String? book(Service s) {
    final u = me!;
    if (activeTicketOf(u.id) != null) {
      return tr('لديك تذكرة فعّالة بالفعل. يرجى إلغاؤها قبل حجز خدمة أخرى.',
          'You already have an active ticket. Please cancel it before booking another service.');
    }
    if (!s.open) {
      return tr('هذه الخدمة مغلقة حاليًا.', 'This service is currently closed.');
    }
    final t = _addTicket(s, u, notified: false);
    _addNotice(u.id, 'تم حجز التذكرة', 'Ticket booked', 'رقم تذكرتك ${t.code} في ${s.nameAr}.',
        'Your ticket is ${t.code} for ${s.nameEn}.');
    _refresh();
    return null;
  }

  void cancel(Ticket t) {
    t.status = TicketStatus.cancelled;
    t.endedAt = DateTime.now();
    _refresh();
  }

  void confirmArrival(Ticket t) {
    t.arrived = true;
    _addNotice(t.studentId, 'تم تأكيد الوصول', 'Arrival confirmed', 'تم تسجيل وصولك إلى المكتب.',
        'Your arrival at the office was recorded.');
    _refresh();
  }

  // ---------------------------------------------------------------
  // إجراءات الموظف
  // ---------------------------------------------------------------
  void callNext(Service s) {
    if (s.paused || currentOf(s.id) != null) return;
    final q = queueOf(s.id);
    if (q.isEmpty) return;
    final t = q.first;
    t.status = TicketStatus.called;
    t.calledAt = DateTime.now();
    _addNotice(t.studentId, 'دورك الآن!', "It's your turn!", 'توجّه الآن إلى شباك ${s.desk} – ${s.nameAr}.',
        'Please go to window ${s.desk} – ${s.nameEn}.');
    _refresh();
  }

  void startServing(Ticket t) {
    t.status = TicketStatus.serving;
    t.startedAt = DateTime.now();
    t.arrived = true;
    _addNotice(t.studentId, 'بدأت خدمتك', 'Service started', 'يتم الآن تنفيذ طلبك.', 'Your request is being handled now.');
    _refresh();
  }

  void complete(Ticket t) {
    t.status = TicketStatus.completed;
    t.startedAt ??= DateTime.now();
    t.endedAt = DateTime.now();
    _addNotice(t.studentId, 'تمت الخدمة', 'Service completed', 'شكرًا لك. تمت خدمتك بنجاح.', 'Thank you. Your service is complete.');
    _refresh();
  }

  void skip(Ticket t) {
    t.status = TicketStatus.missed;
    t.endedAt = DateTime.now();
    _addNotice(t.studentId, 'تم تخطي تذكرتك', 'Ticket skipped', 'لم تحضر في الوقت المحدد فتم تخطي تذكرتك ${t.code}.',
        'You did not arrive in time, so ticket ${t.code} was skipped.');
    _refresh();
  }

  void cancelByStaff(Ticket t) {
    t.status = TicketStatus.cancelled;
    t.endedAt = DateTime.now();
    _addNotice(t.studentId, 'تم إلغاء تذكرتك', 'Ticket cancelled', 'قام الموظف بإلغاء تذكرتك ${t.code}.',
        'Staff cancelled your ticket ${t.code}.');
    _refresh();
  }

  void togglePause(Service s) {
    s.paused = !s.paused;
    _refresh();
  }

  // ---------------------------------------------------------------
  // أدوات المحاكاة (للعرض فقط)
  // ---------------------------------------------------------------
  void demoStep(Service s) {
    final cur = currentOf(s.id);
    if (cur != null) {
      if (cur.studentId == me?.id) return;
      cur.status = TicketStatus.completed;
      cur.startedAt ??= DateTime.now();
      cur.endedAt = DateTime.now();
    }
    s.paused = false;
    callNext(s);
    _refresh();
  }

  void demoFinish(Ticket t) {
    t.arrived = true;
    complete(t);
  }

  // ---------------------------------------------------------------
  // الأدمن
  // ---------------------------------------------------------------
  void setServiceOpen(Service s, bool v) {
    s.open = v;
    _refresh();
  }

  void updateService(Service s, String ar, String en, int? avg) {
    if (ar.isNotEmpty) s.nameAr = ar;
    if (en.isNotEmpty) s.nameEn = en;
    if (avg != null && avg > 0) s.avgMinutes = avg;
    _refresh();
  }

  void addService(String placeId, String ar, String en, int avg) {
    final code = String.fromCharCode(65 + (services.length % 26));
    services.add(Service(
      id: 's${_seq++}',
      placeId: placeId,
      code: code,
      nameAr: ar,
      nameEn: en,
      avgMinutes: avg,
    ));
    _refresh();
  }

  String? addEmployee(String name, String nid, String code, String placeId) {
    if (name.isEmpty || code.isEmpty) {
      return tr('من فضلك املأ كل الحقول', 'Please fill in all fields');
    }
    if (nid.length != 14 || int.tryParse(nid) == null) {
      return tr('الرقم القومي يجب أن يكون 14 رقمًا', 'National ID must be 14 digits');
    }
    final dup = users.any((u) =>
        u.nationalId == nid || u.academicId.toUpperCase() == code.toUpperCase());
    if (dup) {
      return tr('هذا الحساب موجود بالفعل', 'This account already exists');
    }
    users.add(AppUser(
      id: 'u${_seq++}',
      nameAr: name,
      nameEn: name,
      nationalId: nid,
      academicId: code,
      role: Role.employee,
      placeId: placeId,
    ));
    _refresh();
    return null;
  }

  void setUserActive(AppUser u, bool v) {
    u.active = v;
    _refresh();
  }

  // ---------------------------------------------------------------
  // الإحصائيات
  // ---------------------------------------------------------------
  bool _sameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  List<Ticket> get todayTickets {
    final now = DateTime.now();
    return tickets.where((t) => _sameDay(t.createdAt, now)).toList();
  }

  int countToday(TicketStatus st) =>
      todayTickets.where((t) => t.status == st).length;

  double get avgWaitMinutes {
    final l = todayTickets.where((t) => t.startedAt != null).toList();
    if (l.isEmpty) return 0;
    int sum = 0;
    for (final t in l) {
      sum += t.startedAt!.difference(t.createdAt).inMinutes;
    }
    return sum / l.length;
  }

  Service? get busiestService {
    Service? best;
    int bestN = 0;
    for (final s in services) {
      final n = queueOf(s.id).length;
      if (n > bestN) {
        bestN = n;
        best = s;
      }
    }
    return best;
  }

  // ---------------------------------------------------------------
  // الإشعارات
  // ---------------------------------------------------------------
  void _addNotice(String uid, String ta, String te, String ba, String be) {
    notices.insert(
      0,
      Notice(userId: uid, titleAr: ta, titleEn: te, bodyAr: ba, bodyEn: be, time: DateTime.now()),
    );
  }

  List<Notice> noticesOf(String uid) =>
      notices.where((n) => n.userId == uid).toList();

  int unreadOf(String uid) =>
      notices.where((n) => n.userId == uid && !n.read).length;

  void markRead(String uid) {
    for (final n in notices) {
      if (n.userId == uid) n.read = true;
    }
    notifyListeners();
  }

  void _checkNotify() {
    for (final t in tickets) {
      if (t.status == TicketStatus.waiting && !t.notified && estWait(t) <= kNotifyMinutes) {
        t.notified = true;
        final s = serviceById(t.serviceId);
        _addNotice(
          t.studentId,
          'دورك يقترب',
          'Your turn is near',
          'تبقّى حوالي $kNotifyMinutes دقائق على دورك في ${s.nameAr}.',
          'About $kNotifyMinutes minutes left before your turn at ${s.nameEn}.',
        );
      }
    }
  }

  void _refresh() {
    _checkNotify();
    notifyListeners();
  }

  /// كل ثانية: لو طالب اتنادى عليه وماوصلش في المهلة، بنتخطاه وننادي اللي بعده.
  void _tick() {
    final now = DateTime.now();
    bool changed = false;
    for (final t in List<Ticket>.from(tickets)) {
      if (t.status == TicketStatus.called &&
          !t.arrived &&
          t.calledAt != null &&
          now.difference(t.calledAt!).inSeconds >= kGraceSeconds) {
        t.status = TicketStatus.missed;
        t.endedAt = now;
        _addNotice(t.studentId, 'تم تخطي تذكرتك', 'Ticket skipped', 'انتهت مهلة الحضور فتم تخطي تذكرتك ${t.code}.',
            'The arrival time ran out, so ticket ${t.code} was skipped.');
        callNext(serviceById(t.serviceId));
        changed = true;
      }
    }
    if (changed) _refresh();
  }
}
